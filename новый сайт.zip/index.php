 <html xmlns="http://www.w3.org/1999/xhtml" lang="ru" xml:lang="ru" class="js ya-page_js_yes" style="height: 100%;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<head>
	<title>Мифические истории</title>
	<meta property="og:description" content="Творю чаго хочу">
	<meta name="description" content="Творю чаго хочум">
	<link rel="shortcut icon" href="glavnay/images/кнопка главная.png" type="image/x-icon" /> 
	<link rel="stylesheet" type="text/css" href="glavnay/css/menu.css" />
	<link rel="stylesheet" type="text/css" href="glavnay/css/content_glavnay.css" />
	<link rel="stylesheet" type="text/css" href="glavnay/css/podval.css" />
</head>
<style>
	.textuser {
		text-align: right;
		margin-right: 250px;
		font: 10pt sans-serif;
		list-style-type: none;
		
		} 
	   h1 {
		font: 200% serif;
	   }
	#menu.css { z-index: 1; }
	#content.css { z-index: 2; }
</style>
<body>
<div>
<li class="textuser" id="menu-Вход"><a href="#">Регистрация</a>|<a href="#">Вход</a>|<a href="#">Забыли пароль</a></li>
</div>
<div>
<center>
<div id="container">
<ul id="menu">
  <li><a href="Главная.html">Главная</a></li>
  <li><a>Мифологические существа народов мира</a>
		<ul>
			<li><a href="Славянские мифические существа.html">Славянские мифические существа</a></li>
			<li><a href="#">Мифические существа древней греции</a></li>
			<li><a href="#">Мифические существа скандинавии</a></li>
			<li><a href="#">Английские мифические существа</a></li>
			<li><a href="#">Мифические существа Японии</a></li>
			<li><a href="#">Мифические существа Южной Америки</a></li>
			<li><a href="#">Мифические существа Африки</a></li>
		</ul>
	</li>
	<li><a>Мифологические существа разного времени</a>
		<ul>
			<li><a href="#">Современные мифические существа</a></li>
			<li><a href="#">Древние мифические существа</a></li>
		</ul>
	</li>
	<li><a>Форум</a>
		<ul>
			<li><a href="#">Беседка</a></li>
			<li><a href="#">Флудилка</a></li>
			<li><a href="#">Ваши истории</a></li>
		</ul>
	</li>
	<li><a href="#">О нас</a></li>
</ul>
</div>
<div>
	<div class="main">
		<div class="container">
			<div class="row">
			  <div class="col-1-2"><font size="5" color="red" align="left" align="left"><p align="center"> тут основная информация </p></font></div>
			  <div class="col-1-3"><font size="5" color="red" align="left" align="left"><p align="center"> тут рекала/новые посты </p></font></div>
			</div>
		</div>
	</div>
</div>
<footer id="podval">
	<div  class="thumb_podval" align="left">
	<div><p><a><a href="https://instagram.com/susanin5000/" target="_blank"><img style="margin-top: 10px;" src="glavnay/images/insta.jfif" width="50" height="50" alt="я в instagramm" title="я в instagramm"></a>
	<a href="https://vk.com/goose_alex" target="_blank"><img src="glavnay/images/VK.png" width="50" height="50" alt="я во вконтакте" title="я во вконтакте"></a></a></p>
	</div>
	&copy; Алексей Гусев
	</div>
</footer>
</body>
</html>